# Development Log: Phase 3.5 — Backend Technical Debt Resolution

Date: 2026-11-10. Between Day 21 and Day 22. Report: [phase_3_technical_debt_resolution.md](../development/phase_3_technical_debt_resolution.md).

Baseline: Days 16–21 complete and uncommitted on top of `df2b9e0`; 1631 tests passing.

## Inventory

Sources: `technical_debt.md`, the Day 16–21 docs and logs, and `ponytail:`/TODO markers (the only TODO-style markers are 4 `ponytail:` comments). 17 findings in total:
- 9 fixed and verified: TD-009, 010, 011, 013, 018, 019, 020, 021, 025;
- 6 need approval: TD-014, 015, 016, 017, 022, 023;
- 2 open: TD-024 revocation, and TD-026 mutable lists (Decision E).

## What was built

- **TD-009:** `get_read_session` makes every read transaction `READ ONLY` (an `after_begin` listener, so invalid requests still do no I/O).
- **TD-010:** `repositories.get_released_quotation`, a keyed lookup with the owner and release filters in SQL.
- **TD-011:** `find_materials(limit=, offset=)`, paged in SQL.
- **TD-013:** `RFQ_API_JWT_PUBLIC_KEYS` named key set, with exact `kid` selection.
- **TD-020:** `rfq_copilot/paths.py`, an ancestor walk through descriptors, used by the key loader and the storage directory.
- **TD-019:** upload flushes before COMMIT; an uncertain COMMIT keeps the file.
- **TD-018:** `rfq_copilot/reconcile_attachments.py`, an operator reconciler (dry run by default).
- **TD-021:** `rfq_copilot/pdf_worker.py` plus `attachments.extract_pdf_isolated`, a killable child process with a deadline; new reason `pdf_too_complex`.
- **Tests:**
  - `tests/test_phase3_hardening.py`: 47 public tests, added to smoke;
  - `tests/test_phase3_hardening_database.py`: 7 PostgreSQL tests.

## Existing tests adapted (invariants kept)

- `test_api_reads.py`:
  - the quote unit tests patch `get_released_quotation`, and the route still refuses an unreleased quote even if the repository returned one;
  - the material fake now pages like SQL.
- `test_day18_api_database.py`: a missing quote costs 1 SELECT (was 3). This is tighter, not weaker.
- `test_attachments.py`: the "database failure removes the file" and "cancellation removes the file" tests now fail at flush, the certain-failure stage. The COMMIT-stage behaviour deliberately changed (TD-019) and has new tests.

## Problems found and fixed

1. **Read-only first try broke an invariant:** issuing `SET TRANSACTION READ ONLY` eagerly in the dependency turned the 422s into 503s against an unreachable database, breaking the "validation does no I/O" invariant. Switched to the session's `after_begin` event.
2. **Wrong expected status:** the savepoint test wrapper does not map driver errors the way `Database.session` does (500 instead of 503). Kept that test for the refusal itself and added a real writable `Database` test that expects the production 503.
3. **Silent early return:** a test returned early when the "foreign" user was the owner. It was replaced by an explicit second user of the same role, so it cannot pass silently.
4. **PyJWT refuses non-string `kid`:** those tokens are now built by hand.
5. **Misplaced async marks:** a regex placed `pytest.mark.asyncio` on sync tests (warnings). The marks are now placed directly above each `async def`.
6. **Disposable restore not possible:** neither role has CREATEDB (checked read only). The restore check is not possible without a privilege decision (Decision D); no other role was used.

## Verification (commands and actual results)

| Command | Result |
| --- | --- |
| `.venv/bin/python -m pytest -q tests/test_phase3_hardening.py tests/test_phase3_hardening_database.py` | 54 passed in 6.30s |
| Days 16–21 API and security tests (10 files) | 512 passed in 25.36s |
| Public smoke (9 files, `env -u DATABASE_URL -u TEST_DATABASE_URL`) | 548 passed in 5.77s |
| `.venv/bin/python -m pytest -q` | 1685 passed in 167.15s; 0 failed, 0 skipped, 0 warnings |
| Mutations (8; temporary copies, restored and checksum-verified) | 2 / 2 / 1 / 6 / 5 / 3 / 1 / 3 failed |
| `ruff check .` / `ruff format --check src tests alembic` / `uv lock --check` | pass / 117 files formatted / pass |
| `python -m rfq_copilot.integrity --target development …` | PASS, 1090 records, 0 violations |
| `python -m rfq_copilot.reconcile_attachments` (scratch directory, dry run) | counts only, nothing deleted |
| Uvicorn, two-key set, development read only | kid a/b: 403 (unbound); wrong-key, unknown or missing kid: 401; no secrets in the log |
| Guarded test database | 0 user relations |

Not changed: ORM models, migrations, dataset, role/permission data, business rules, approval policies, bindings, development data. No dependency added.

## Git status at end of phase

Nothing staged or committed. `day21_review_bundle.zip` appeared in the working tree during the phase; it was not created by this session and was left untouched.

```
 M .github/workflows/smoke.yml
 M README.md
 M docs/development/day_19_file_uploads_extraction.md
 M docs/development/technical_debt.md
 M pyproject.toml
 M src/rfq_copilot/api/app.py
 M src/rfq_copilot/api/auth.py
 M src/rfq_copilot/api/config.py
 M src/rfq_copilot/api/db.py
 M src/rfq_copilot/api/routers/attachments.py
 M src/rfq_copilot/api/routers/customers.py
 M src/rfq_copilot/api/routers/materials.py
 M src/rfq_copilot/api/routers/quotes.py
 M src/rfq_copilot/api/routers/rfqs.py
 M src/rfq_copilot/attachments.py
 M src/rfq_copilot/integrity.py
 M src/rfq_copilot/models/__init__.py
 M src/rfq_copilot/models/identity.py
 M src/rfq_copilot/repositories/__init__.py
 M src/rfq_copilot/repositories/queries.py
 M src/rfq_copilot/seeding/mapping.py
 M src/rfq_copilot/seeding/safety.py
 M tests/test_api_reads.py
 M tests/test_attachments.py
 M tests/test_database_end_to_end.py
 M tests/test_database_integrity.py
 M tests/test_database_migrations.py
 M tests/test_database_seeding.py
 M tests/test_day18_api_database.py
 M tests/test_day19_attachments_database.py
 M tests/test_orm_models.py
 M uv.lock
?? alembic/versions/20261110_01_user_customer_bindings.py
?? day21_review_bundle.zip
?? docs/dev_log/day_20.md
?? docs/dev_log/day_21.md
?? docs/dev_log/phase_3_hardening.md
?? docs/development/day_20_authentication.md
?? docs/development/day_21_rbac_authorization.md
?? docs/development/phase_3_technical_debt_resolution.md
?? src/rfq_copilot/api/tokens.py
?? src/rfq_copilot/paths.py
?? src/rfq_copilot/pdf_worker.py
?? src/rfq_copilot/reconcile_attachments.py
?? src/rfq_copilot/repositories/identity.py
?? tests/test_auth.py
?? tests/test_day20_auth_database.py
?? tests/test_day21_rbac_database.py
?? tests/test_phase3_hardening.py
?? tests/test_phase3_hardening_database.py
?? tests/test_rbac.py
```

## Correction — 2026-11-11: attachment reconciliation (audit findings)

1. **Inode reuse:** the replacement file could be deleted when its inode was reused.
   - `_remove_if_still_orphan` now renames to a private random name, verifies via `fstat` on an `O_NOFOLLOW` descriptor (device, inode, size, `st_mtime_ns`, age), and only then unlinks.
   - Otherwise it restores with `link` (no overwrite) or keeps the file under the private name and counts it.
2. **Wrong pairing:** `--delete` now requires a binding marker matching the queried database's fingerprint. `--bind` is allowed only for the development target and the API's `RFQ_API_ATTACHMENT_DIR` (compared by inode). `--bind` and `--delete` are mutually exclusive.

**Files:**
- `src/rfq_copilot/reconcile_attachments.py` (rewritten);
- `tests/test_phase3_reconcile.py` (new, 19);
- `tests/test_phase3_hardening.py` (the CLI fake returns the new result shape);
- `tests/test_phase3_hardening_database.py` (+1 real fingerprint test);
- `.github/workflows/smoke.yml`, `README.md`, `technical_debt.md`, `phase_3_technical_debt_resolution.md`.

**Problems along the way:**
1. The first write of the module was refused because the file had to be re-read first.
2. Two CLI tests used the default 24 h grace with 2 h-old files; they now pass `--grace-hours 1`.

**Verification (actual):**

| Command | Result |
| --- | --- |
| focused tests | 19 passed in 0.30s |
| Phase 3.5 tests | 74 passed in 6.31s |
| attachment tests | 133 passed in 5.08s |
| Days 16–21 API tests | 512 passed in 25.18s |
| smoke | 567 passed in 5.79s |
| full | 1705 passed in 166.13s; 0 failed, 0 skipped, 0 warnings |
| mutations (old removal / no pairing / bind no dir check / no age recheck) | 4 / 2 / 1 / 5 failed |
| ruff / format / lock | pass / 118 files / pass |
| integrity (development) | PASS, 1090 records |
| CLI dry run, then `--delete` on unbound storage | `unbound`; refused (exit 2) |
| guarded test database | 0 user relations |

Nothing staged or committed. No business services, ORM models, migrations, dataset, RBAC policies or approvals changed.
