# Phase 3.5: Backend Technical Debt Resolution

Date: 2026-11-10. Scope: findings from Days 16–21. Baseline: 1631 passing tests. Result: 1685 passing (+54), 0 failed, 0 skipped, 0 warnings.

**Verdict: PARTIAL — APPROVAL REQUIRED.** Every safe in-scope correction is implemented and verified. Six findings need a policy or schema decision (Decisions A–E); nothing was changed for them.

## Finding inventory (before → after)

| ID | Source | Before | Risk | After | Approval |
| --- | --- | --- | --- | --- | --- |
| TD-009 | Day 18 | Injected `Database` trusted as read-only | A read path could write | RESOLVED_VERIFIED: every read transaction is `READ ONLY` | no |
| TD-010 | Day 18 | Quote lookup loaded the whole history | Slow requests as history grows | RESOLVED_VERIFIED: keyed SQL, 3 SELECTs (1 for 404) | no |
| TD-011 | Day 18 | Catalog paged in Python | Cost grows with catalog size | RESOLVED_VERIFIED: LIMIT/OFFSET in SQL | no |
| TD-013 | Day 20 | One static key | Rotation needs a hard cut-over | RESOLVED_VERIFIED: trusted key set with exact `kid` | no |
| TD-024 | Day 20 (split) | No revocation before `exp` | Stolen token valid until `exp` | OPEN: needs identity-provider integration | design |
| TD-022 | Day 20 | Bindings only via SQL | Unaudited manual grants | BLOCKED_APPROVAL (Decision C) | yes |
| TD-014 | Day 21 | Catalog and quotes reuse `view_assigned_rfqs` | Mismatch with the reference policy | BLOCKED_APPROVAL (Decision A) | yes |
| TD-016 | Day 21 | Upload reuses `create_rfq` | Imprecise least privilege | BLOCKED_APPROVAL (Decision A) | yes |
| TD-015 | Day 21 | "Assigned" means the bound customer | Over-broad once many staff share a customer | BLOCKED_APPROVAL (Decision B) | yes |
| TD-017 | Day 21 | One customer per user | No multi-customer staff model | BLOCKED_APPROVAL (Decision B) | yes |
| TD-018 | Day 19 | Crash leaves an orphan file | Disk growth, stale documents | RESOLVED_VERIFIED: operator reconciler | no |
| TD-019 | Day 19 / review | Failed COMMIT deleted the file | Committed row without its file | RESOLVED_VERIFIED: no blind delete | no |
| TD-020 | Days 19–20 | Ancestor directories unchecked | Path redirection by another user | RESOLVED_VERIFIED: descriptor walk from `/` | no |
| TD-021 | Day 19 | PDF parse had no deadline | A hostile PDF pins a worker thread | RESOLVED_VERIFIED: killable child process | no |
| TD-023 | Day 20 | Backup never test-restored | An unrestorable backup goes unnoticed | BLOCKED_APPROVAL (Decision D) | yes (privilege) |
| TD-025 | Day 17 | Forgotten registry entry undetected | Unhelpful redacted errors | RESOLVED_VERIFIED: detection test | no |
| TD-026 | Day 17 | Frozen models hold lists | None today (no reliance) | OPEN (Decision E) | confirm |

Also reviewed:
- **Development dependencies:** every imported module is declared. Pillow and ReportLab are not used, so they were not added.
- **Validation-message usability:** messages stay static, with no limits or values, to avoid reflection. No change.
- **Markers:** the `ponytail:` comments in `routers/quotes.py` (the TD-010 shortcut) are removed. Those in `attachments.py`, `schemas/rfq.py` and `services/materials.py` are bounded, documented shortcuts and are kept.
- TD-001, TD-006 and TD-007 predate Day 16 and are unchanged.

## Implemented corrections

| Area | Change | Files |
| --- | --- | --- |
| Read-only reads (TD-009) | `after_begin` listener issues `SET TRANSACTION READ ONLY` in every read session, only when the route queries | `api/db.py` |
| Quote lookup (TD-010) | `get_released_quotation(session, quote_id, customer_id=)`: id, owner, `released` and `released_at` in the WHERE clause; shared result builder | `repositories/queries.py`, `repositories/__init__.py`, `api/routers/quotes.py` |
| Catalog paging (TD-011) | `find_materials(..., limit=, offset=)`, validated; the route asks for `limit + 1` | `repositories/queries.py`, `api/routers/materials.py` |
| Key rotation (TD-013) | `RFQ_API_JWT_PUBLIC_KEYS` (1–4 named keys, each through the secure loader); exact-`kid` selection, no fallback | `api/config.py`, `api/tokens.py` |
| Path trust (TD-020) | `open_trusted_parent`: realpath once, then `O_NOFOLLOW` per component from `/`; root or service owner; no group/other write unless sticky | new `paths.py`; `api/tokens.py`, `attachments.py` |
| Ambiguous COMMIT (TD-019) | Flush first, so a certain failure removes the file; a COMMIT failure or cancellation keeps it for reconciliation | `api/routers/attachments.py` |
| Orphans (TD-018) | `python -m rfq_copilot.reconcile_attachments`: dry run, grace ≥ 1 h, `flock`, DB and inode recheck, counts only | new `reconcile_attachments.py` |
| PDF deadline (TD-021) | `python -I -m rfq_copilot.pdf_worker`, empty env, CPU and memory rlimits, killed at 15 s; strict output validation; reason `pdf_too_complex` | new `pdf_worker.py`; `attachments.py`, `api/routers/attachments.py` |
| Registry (TD-025) | Tests: every declared parameter is trusted; unregistered nested fields stay redacted | tests only |

## Security review

- **Authentication:**
  - Day 20 behaviour is unchanged in single-key mode.
  - Key-set mode adds exact `kid` selection only. Unknown, missing, near-miss or non-string `kid` gives 401; `jku`/`jwk`/`x5u`/`x5c` are still refused.
  - Key files and all their ancestors are verified through descriptors.
- **RBAC:** unchanged. No permission, grant or role was added, and the matrix tests still pass.
- **Customer isolation:** the quote lookup now enforces ownership in SQL. A same-role user bound to another customer gets 404 (tested), and the cross-customer 404 tests from Days 18–21 pass.
- **Uploads:**
  - Authorization still happens before the body is read.
  - The storage path is fully verified; PDF parsing is isolated and time-bounded.
  - Uncertain commits never delete; certain failures still leave nothing behind.
- **Approval policy:** no approval, release or draft route exists. `approval-v1.2`/`v1.1`, `snapshot_session()`, REPEATABLE READ evaluation, Decimal pricing and the fingerprints are untouched.

## Performance

| Operation | Before | After |
| --- | --- | --- |
| `GET /quotes/{id}`, released | All quotes of the customer, plus their versions and lines | 3 SELECTs, one quote |
| `GET /quotes/{id}`, missing or unreleased | 3 SELECTs over the whole history | 1 SELECT, keyed |
| `GET /materials` | Every matching id fetched, sliced in Python | `ORDER BY material_id LIMIT n+1 OFFSET k`, then the page rows |
| Read sessions | — | +1 `SET TRANSACTION READ ONLY` per queried request (same round trip pattern as BEGIN) |
| PDF upload | In-thread parse | About 0.1 s of child-process start-up; hard deadline |

## Approval decisions required

### Decision A — Permission vocabulary for the catalog, quotes and uploads (TD-014, TD-016)

**Differences, current mapping vs the dataset's reference tool policy (`src/security_policy.py`, test reference only):**

| Operation | Current (DB grants of `view_assigned_rfqs` / `create_rfq`) | Reference | Difference |
| --- | --- | --- | --- |
| Catalog read | sales rep, estimator, mfg engineer, **sales manager** | `get_material_specs`: sales rep, estimator, mfg engineer | sales manager has extra access |
| Released quote read | sales rep, estimator, **mfg engineer**, sales manager | `get_quote_status`: sales rep, estimator, sales manager, **auditor** | mfg engineer has extra access; auditor is missing |
| Attachment upload | sales rep, estimator (`create_rfq`) | no attachment tool; `create_rfq`: sales rep, estimator | none in effect; the semantics are imprecise |

- **Recommended:** a new, versioned policy revision outside the frozen dataset (an Alembic data revision plus updated seeding and integrity contracts) that:
  - adds the permissions `view_catalog`, `view_quote` and `attach_rfq_document`;
  - grants `view_catalog` to sales rep, estimator and mfg engineer, `view_quote` to sales rep, estimator, sales manager and auditor, and `attach_rfq_document` to sales rep and estimator;
  - then switches the three `require_permission` arguments.

  Net effect: least privilege that matches the reference. Sales managers lose catalog reads, mfg engineers lose quote reads, auditors gain released-quote reads, and uploads are unchanged.
- **Alternatives:**
  1. Keep the current mapping and accept the documented mismatch.
  2. Restrict only, with no new grants, by mapping quotes to a permission auditors lack. This cannot express the reference without new records.
- **Schema/policy changes:** 3 `permissions` rows and 9 `role_permissions` rows. Pinned counts change (permissions 12 → 15, grants 27 → 36, integrity record count) and need a documented post-dataset policy layer.
- **Tests:** a matrix update; the per-role database test derives the new expectations automatically; the reference-parity table becomes a test.
- **Migration and rollback risk:** additive data only. A downgrade deletes the new grants and permissions after switching the routes back. The risk is a mismatch between seeded data and pinned counts if the migration is applied without the code.

### Decision B — Staff assignment and multi-customer access (TD-015, TD-017)

- **Recommended:** keep today's model for Day 22. Defer both to an explicit authorization phase, with:
  - a new table `business.rfq_staff_assignments (rfq_id, user_id, assigned_by, assigned_at, revoked_at)` with a partial unique index on active rows. RFQ reads for holders of `view_assigned_rfqs` would require an active assignment in addition to customer ownership in SQL;
  - multi-customer staff through several active bindings, plus a customer selected in the URL path (`/customers/{customer_id}/…`), validated against the caller's active bindings on every request. Never from headers or claims. This replaces the single-active-binding index only together with that check.
- **Alternatives:**
  1. Assignment by region (`users.assigned_region`), rejected: it invents a relationship.
  2. A "global staff" permission, rejected: implicit all-customer access.
- **Security:** both changes narrow or explicitly widen access. Each needs audit events and tests proving that ownership is still enforced.
- **Migration risk:** a new table (additive). Dropping the unique index is a behavioural change that needs a coordinated code release; rollback requires removing extra active bindings first.
- **Tests:** an unassigned RFQ of the same customer gives 404; selecting a customer the caller has no binding to gives 403 or 404; forged headers or claims give no effect.

### Decision C — Binding provisioning and upload idempotency (TD-022, TD-019 residual)

- **Recommended:** an operator command `python -m rfq_copilot.bindings grant|revoke --user U --customer C --operator O --reason R`, run with a writable maintenance role, in one transaction:
  - **Customer verification:** the customer exists and is not `inactive`, and the user is active.
  - **Conflicts:** refuse a second active binding (the existing partial index) unless `--replace` revokes the old one in the same transaction.
  - **Revocation:** sets `revoked_at`; history is never deleted.
  - **Audit:** writes an `audit_events` row (`actor_id` = operator, `outcome`, a reason in `event_data`).
  - **Failure:** a single transaction, so rollback is all or nothing; no partial state.
- **Decisions needed:**
  - **Operator authority:** a new `manage_bindings` permission, or DBA-only.
  - **Audit vocabulary:** which `event_type` values to use.
  - **Upload idempotency:** whether uploads should accept an idempotency key stored in the existing `idempotency_records`, so a retry after an ambiguous 503 returns the original attachment.
- **Alternatives:** keep SQL provisioning with a written runbook.
- **Tests:** grant, duplicate, replace, revoke, inactive customer, unknown user, audit row present, rollback on failure.

### Decision D — Restore verification of the development backup (TD-023)

- **Recommended:** a DBA creates a disposable database (for example `rfq_copilot_restore_check`) owned by a maintenance role. `pg_restore` into it, compare the per-table fingerprints with those recorded on 2026-11-10, then drop it.
- **Alternative:** grant CREATEDB to a separate maintenance role (never to the application roles).
- **Risk:** none to development or test data. It must never target `rfq_copilot_dev` or the guarded test database.

### Decision E — Confirm intentional constraints (TD-026 and deployment assumptions)

These are recorded as intentional; they are **not** marked accepted:
- frozen models with lists, versus switching to tuples (same JSON);
- symlinked secret layouts are refused (point to the resolved file);
- ancestors owned by another non-root user are refused;
- POSIX only;
- key rotation needs a restart.

## Verification (actual)

| Command | Result |
| --- | --- |
| `pytest -q tests/test_phase3_hardening.py tests/test_phase3_hardening_database.py` | 54 passed in 6.30 s |
| Days 16–21 API and security tests (10 files) | 512 passed in 25.36 s |
| Public smoke (9 files, no database variables) | 548 passed in 5.77 s |
| `pytest -q` | **1685 passed** in 167.15 s; 0 failed, 0 skipped, 0 warnings |
| Mutations: read-only listener / quote owner filter / SQL paging / kid fallback / ancestor checks / uncertain-commit delete / in-process PDF / grace ignored | 2 / 2 / 1 / 6 / 5 / 3 / 1 / 3 failed (of 54) |
| `ruff check .` / `ruff format --check src tests alembic` / `uv lock --check` | pass / 117 files formatted / pass |
| `integrity --target development` (read only) | PASS, 1090 records, 0 violations |
| Reconciler dry run (scratch directory, development DB read only) | counts only; nothing deleted |
| Uvicorn, production, two-key set, development DB read only | live and info 200; kid a and kid b: 403 (verified, unbound); kid a header with a key b signature, unknown kid, no kid, bad signature: 401; no token, subject or error in the log |
| Guarded test database afterwards | 0 user relations |

## Correction — 2026-11-11: reconciler audit findings (TD-018)

- **Inode reuse:** a replacement that reuses the original inode was deletable.
  - **Fix:** removal is now an atomic rename to a private random name, then `fstat` verification on the opened descriptor (device, inode, size, mtime in nanoseconds, still past the grace period), then unlink.
  - On doubt the file is restored without overwriting, or kept under the private name and reported.
- **Wrong database/storage pairing:** development storage could be reconciled against the test database.
  - **Fix:** `--delete` requires a binding marker matching the queried database's fingerprint (name and OID, hashed).
  - `--bind` is allowed only for the API's pairing: the development target and the same directory as `RFQ_API_ATTACHMENT_DIR`, compared by inode.
  - A dry run is unaffected.

| Command | Result |
| --- | --- |
| `pytest -q tests/test_phase3_reconcile.py` | 19 passed in 0.30 s |
| Phase 3.5 tests (3 files) | 74 passed in 6.31 s |
| Attachment security tests | 133 passed in 5.08 s |
| Days 16–21 API and security tests | 512 passed in 25.18 s |
| Public smoke (10 files) | 567 passed in 5.79 s |
| `pytest -q` | **1705 passed** in 166.13 s; 0 failed, 0 skipped, 0 warnings |
| Mutations: old removal / no pairing check / bind without directory check / no age recheck | 4 / 2 / 1 / 5 failed |
| `ruff check .` / `ruff format --check` / `uv lock --check` | pass / 118 files formatted / pass |
| `integrity --target development` | PASS, 1090 records, 0 violations |
| CLI on a scratch directory, development DB read only | dry run: `pairing: unbound`; `--delete`: refused, exit 2 |

TD-018 stays RESOLVED_VERIFIED on the strength of these tests. The residual risks are in `technical_debt.md`.

## Remaining risks and Day 22 readiness

- **Day 22 can begin** on the current authorization model. Decisions A–C change least-privilege precision and operations, not isolation. Customer isolation, authentication, upload safety and approval protections are verified.
- Open: TD-024 (revocation), TD-026 (Decision E), TD-001/006/007 (earlier phases).
- New routes in Day 22 must use `require_permission`, appear in the RBAC matrix test, and keep read paths on `get_read_session`.
