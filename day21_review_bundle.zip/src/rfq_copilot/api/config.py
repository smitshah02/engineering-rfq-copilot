"""Typed API settings from ``RFQ_API_*`` process variables.

Deliberately separate from the database configuration: no dotenv file is read, so the
API never reinterprets ``DATABASE_URL`` and starts without database credentials.
"""

import os
from collections.abc import Mapping
from pathlib import Path
from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

ENV_PREFIX = "RFQ_API_"

_ClaimText = Annotated[str, Field(min_length=1, max_length=255, pattern=r"^[\x21-\x7e]+$")]


class ApiSettings(BaseModel):
    """Validated, immutable API settings. Unknown ``RFQ_API_*`` variables are rejected."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    # Secure default: interactive docs and the OpenAPI schema are served only when a
    # deployment explicitly opts into development.
    environment: Literal["development", "production"] = "production"

    # Attachment uploads answer 503 until a storage directory is configured (absolute path;
    # created with mode 0700 if missing). Files get server-generated names, mode 0600.
    attachment_dir: Path | None = None
    # Largest accepted attachment. The multipart body is capped at this plus a small
    # allowance for part headers, while it streams, before anything is buffered whole.
    max_upload_bytes: Annotated[int, Field(ge=1, le=50 * 1024 * 1024)] = 10 * 1024 * 1024

    # Bearer-token trust boundary: one external issuer, one audience, one asymmetric
    # algorithm and one public key. All four or none; with none, a request carrying a
    # bearer token answers 503 (authentication unavailable) and nothing is authorized.
    # HMAC algorithms are excluded: this service verifies tokens, it never mints them.
    jwt_issuer: _ClaimText | None = None
    jwt_audience: _ClaimText | None = None
    jwt_algorithm: Literal["RS256", "ES256", "EdDSA"] | None = None
    jwt_public_key_file: Path | None = None
    # Longest accepted exp - iat. Tokens with a longer declared lifetime are rejected.
    jwt_max_lifetime_seconds: Annotated[int, Field(ge=60, le=3600)] = 900

    @field_validator("attachment_dir", "jwt_public_key_file")
    @classmethod
    def _absolute(cls, value: Path | None) -> Path | None:
        if value is not None and not value.is_absolute():
            raise ValueError("Path settings must be absolute.")
        return value

    @model_validator(mode="after")
    def _token_settings_complete(self) -> "ApiSettings":
        values = (self.jwt_issuer, self.jwt_audience, self.jwt_algorithm, self.jwt_public_key_file)
        if any(v is not None for v in values) and any(v is None for v in values):
            raise ValueError("JWT settings must be given together or not at all.")
        return self

    @property
    def authentication_configured(self) -> bool:
        return self.jwt_issuer is not None

    @property
    def docs_enabled(self) -> bool:
        return self.environment == "development"

    @classmethod
    def from_env(cls, environ: Mapping[str, str] | None = None) -> "ApiSettings":
        """Build settings from ``RFQ_API_<FIELD>`` variables; raises ``ValidationError``."""
        source = os.environ if environ is None else environ
        values = {
            key.removeprefix(ENV_PREFIX).lower(): value
            for key, value in source.items()
            if key.startswith(ENV_PREFIX)
        }
        return cls(**values)
