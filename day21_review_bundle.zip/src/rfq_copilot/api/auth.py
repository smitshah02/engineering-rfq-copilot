"""Verified identity for customer-scoped routes. Fails closed.

``get_principal`` accepts only ``Authorization: Bearer <JWT>``:
1. No bearer credentials: 401. Headers such as ``X-Customer-Id``, cookies, query and
   body are never read, so no client-supplied value can become an identity.
2. No configured trust boundary (``RFQ_API_JWT_*``): 503. Nothing is authorized.
3. ``TokenVerifier.subject`` checks signature, algorithm, issuer, audience, lifetime and
   subject (``api/tokens.py``). Any failure: 401, before any database access.
4. In a short session of its own (the read-only ``Database``, not the route's session,
   which itself depends on this function), the subject must name an active user in
   ``business.users``; otherwise 401, the same answer as a bad token.
5. The customer comes only from ``repositories.customer_binding``: an unrevoked row in
   ``business.user_customer_bindings`` whose customer's account status is eligible.
   Claims in the token (customer, role, scope) are ignored. No eligible binding: 403.
6. In the same session, the permissions come only from ``repositories.granted_permissions``:
   ``business.role_permissions`` rows with ``allowed = true`` for ``users.role``. Nothing
   is cached, so a grant, role, binding or ``active`` change applies to the next request.

Authorization (Day 21): every protected route depends on ``require_permission(name)``,
which runs ``get_principal`` and answers 403 unless the permission was granted. It never
compares role names. Customer scoping stays in each route's queries (cross-customer: 404).
Tests may still inject a principal with ``app.dependency_overrides[get_principal]``; the
injected principal's ``permissions`` are then checked the same way.
"""

from dataclasses import dataclass
from typing import Annotated

from fastapi import Depends, HTTPException, Request
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from rfq_copilot.api.tokens import InvalidToken

bearer = HTTPBearer(
    auto_error=False,
    scheme_name="BearerToken",
    description="JWT from the configured issuer; its subject must be an active user.",
)


@dataclass(frozen=True)
class Principal:
    """A verified caller, scoped to exactly one customer account."""

    customer_id: str
    permissions: frozenset[str] = frozenset()  # from business.role_permissions; none by default

    def __post_init__(self) -> None:
        value = self.customer_id
        if not isinstance(value, str) or not value.strip() or len(value) > 64 or "\x00" in value:
            raise ValueError("Principal requires a verified customer identifier.")
        if not isinstance(self.permissions, frozenset) or not all(
            isinstance(item, str) for item in self.permissions
        ):
            raise ValueError("Principal permissions must be a frozenset of names.")


def unauthenticated() -> HTTPException:
    return HTTPException(
        status_code=401,
        detail="Authentication required.",
        headers={"WWW-Authenticate": "Bearer"},
    )


def _unavailable() -> HTTPException:
    return HTTPException(status_code=503, detail="Service unavailable.")


async def get_principal(
    request: Request,
    credentials: Annotated[HTTPAuthorizationCredentials | None, Depends(bearer)],
) -> Principal:
    if credentials is None:
        raise unauthenticated()
    verifier = request.app.state.token_verifier
    if verifier is None:
        raise _unavailable()
    try:
        subject = verifier.subject(credentials.credentials)
    except InvalidToken:
        raise unauthenticated() from None

    from rfq_copilot.api.db import get_database
    from rfq_copilot.database import DatabaseError
    from rfq_copilot.repositories import customer_binding, find_active_user, granted_permissions

    database = await get_database(request)
    try:
        async with database.session() as session:
            user = await find_active_user(session, subject)
            customer_id = None if user is None else await customer_binding(session, user)
            granted = None if customer_id is None else await granted_permissions(session, user)
    except DatabaseError:
        raise _unavailable() from None
    if user is None:
        raise unauthenticated()  # unknown or inactive: indistinguishable from a bad token
    if customer_id is None:
        raise HTTPException(status_code=403, detail="Forbidden.")
    return Principal(customer_id, granted)


# Permission names as stored in business.permissions (dataset roles_permissions.csv).
VIEW_CUSTOMER = "view_customer"
VIEW_ASSIGNED_RFQS = "view_assigned_rfqs"
CREATE_RFQ = "create_rfq"


def require_permission(permission: str):
    """A dependency that yields the verified principal only if it holds ``permission``.

    Order: authentication (401), customer binding (403), then this check (403), all before
    the route's own dependencies (session, storage, body). Deny by default.
    """

    async def dependency(principal: Annotated[Principal, Depends(get_principal)]) -> Principal:
        if permission not in principal.permissions:
            raise HTTPException(status_code=403, detail="Forbidden.")
        return principal

    dependency.required_permission = permission  # read by the route-coverage test
    return dependency
