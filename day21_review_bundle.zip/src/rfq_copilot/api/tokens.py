"""Bearer-token verification against one configured issuer (PyJWT).

The trust boundary is fixed by configuration: issuer, audience, one asymmetric algorithm
and one public key. Nothing in a token can change it: the header's ``alg`` must equal
the configured algorithm, key-locating headers (``jku``, ``jwk``, ``x5u``, ``x5c``) and
``crit`` are refused, and ``kid`` never selects a key.

A verified token yields only its subject. Every other claim (customer, role, scope,
email) is ignored; identity and customer come from the database (``api/auth.py``).
Errors are a single ``InvalidToken`` with no detail, so nothing about the token reaches
the client or the logs.
"""

import os
import stat
import time
import unicodedata
from dataclasses import dataclass, field
from typing import Any

import jwt
from cryptography.hazmat.primitives.asymmetric import ec, ed25519, rsa
from cryptography.hazmat.primitives.serialization import load_pem_public_key

from rfq_copilot.api.config import ApiSettings

MAX_TOKEN_CHARS = 4096
MAX_KEY_FILE_BYTES = 16 * 1024
MAX_SUBJECT_CHARS = 255
LEEWAY_SECONDS = 30  # clock skew tolerated for exp, nbf and iat
MIN_RSA_BITS = 2048
_ALLOWED_HEADERS = frozenset({"alg", "typ", "kid"})
_ALLOWED_TYPES = frozenset({"jwt", "at+jwt"})


class InvalidToken(Exception):
    """The token is not acceptable. Deliberately carries no reason."""


class TokenConfigurationError(ValueError):
    """The configured verification key is missing, unsafe or of the wrong kind."""


def _key_matches(algorithm: str, key: Any) -> bool:
    if algorithm == "RS256":
        return isinstance(key, rsa.RSAPublicKey) and key.key_size >= MIN_RSA_BITS
    if algorithm == "ES256":
        return isinstance(key, ec.EllipticCurvePublicKey) and isinstance(key.curve, ec.SECP256R1)
    return isinstance(key, ed25519.Ed25519PublicKey)  # EdDSA


def _trusted(info: os.stat_result) -> bool:
    """Owned by root or by this service's user, and not writable by group or others."""
    return info.st_uid in (0, os.geteuid()) and not info.st_mode & 0o022


def _read_key_file(path: os.PathLike) -> bytes:
    """Read the key file through descriptors, so what is checked is what is read.

    The parent directory is opened and checked first (``fstat``): only its owner (root
    or this service's user) can rename entries in it. The file is then opened relative
    to that descriptor with ``O_NOFOLLOW`` (a symlink as the name fails) and
    ``O_NONBLOCK`` (a FIFO cannot hang startup), and ``fstat`` on the opened descriptor
    checks type, owner and mode. Reading stops after ``MAX_KEY_FILE_BYTES + 1`` bytes.
    Directories above the parent are a deployment assumption (day_20_authentication.md).
    POSIX only.
    """
    folder, name = os.path.split(os.fspath(path))
    unsafe = TokenConfigurationError(
        "JWT public key file must be a regular file owned by root or the service user, "
        "not a symlink, and not group/world-writable, in a directory with the same rules."
    )
    directory = os.open(folder, os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC)
    try:
        if not _trusted(os.fstat(directory)):
            raise unsafe
        flags = os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC
        try:
            descriptor = os.open(name, flags, dir_fd=directory)
        except OSError:
            if stat.S_ISLNK(os.lstat(name, dir_fd=directory).st_mode):
                raise unsafe from None
            raise
    finally:
        os.close(directory)
    with os.fdopen(descriptor, "rb") as handle:
        info = os.fstat(handle.fileno())
        if not stat.S_ISREG(info.st_mode) or not _trusted(info):
            raise unsafe
        data = handle.read(MAX_KEY_FILE_BYTES + 1)
    if len(data) > MAX_KEY_FILE_BYTES:
        raise TokenConfigurationError("JWT public key file is too large.")
    return data


def load_public_key(path: os.PathLike, algorithm: str) -> Any:
    """Load a PEM public key that only root or this server's user can modify.

    A private key, a symlink, an unsafe file or directory (``_read_key_file``), an RSA
    key below 2048 bits, or a key of another type than ``algorithm`` is rejected.
    Messages name no path or key material.
    """
    try:
        key = load_pem_public_key(_read_key_file(path))
    except TokenConfigurationError:
        raise
    except (OSError, ValueError, TypeError):
        raise TokenConfigurationError("JWT public key could not be loaded as a PEM public key.") from None  # fmt: skip
    if not _key_matches(algorithm, key):
        raise TokenConfigurationError("JWT public key does not match the algorithm or is too weak.")
    return key


@dataclass(frozen=True)
class TokenVerifier:
    issuer: str
    audience: str
    algorithm: str
    key: Any = field(repr=False)
    max_lifetime_seconds: int

    @classmethod
    def from_settings(cls, settings: ApiSettings) -> "TokenVerifier | None":
        if not settings.authentication_configured:
            return None
        return cls(
            issuer=settings.jwt_issuer,
            audience=settings.jwt_audience,
            algorithm=settings.jwt_algorithm,
            key=load_public_key(settings.jwt_public_key_file, settings.jwt_algorithm),
            max_lifetime_seconds=settings.jwt_max_lifetime_seconds,
        )

    def subject(self, token: str) -> str:
        """Verify ``token`` and return its subject, or raise ``InvalidToken``."""
        if not isinstance(token, str) or not 0 < len(token) <= MAX_TOKEN_CHARS:
            raise InvalidToken
        if not token.isascii() or token.count(".") != 2:
            raise InvalidToken
        try:
            header = jwt.get_unverified_header(token)
            if (
                not set(header) <= _ALLOWED_HEADERS
                or header.get("alg") != self.algorithm
                or str(header.get("typ", "JWT")).lower() not in _ALLOWED_TYPES
            ):
                raise InvalidToken
            claims = jwt.decode(
                token,
                self.key,
                algorithms=[self.algorithm],  # never the token's own choice
                audience=self.audience,
                issuer=self.issuer,
                leeway=LEEWAY_SECONDS,
                options={
                    "require": ["exp", "iat", "iss", "aud", "sub"],
                    "verify_signature": True,
                    "verify_exp": True,
                    "verify_nbf": True,
                    "verify_iat": True,
                    "verify_aud": True,
                    "verify_iss": True,
                    "strict_aud": True,  # aud must be exactly the configured string
                },
            )
        except InvalidToken:
            raise
        except (jwt.PyJWTError, ValueError, TypeError, KeyError):
            raise InvalidToken from None
        current = time.time()
        issued, expires = claims["iat"], claims["exp"]
        if any(type(value) is not int for value in (issued, expires)):
            raise InvalidToken  # bools and floats are not NumericDate seconds here
        if issued > current + LEEWAY_SECONDS or expires - issued > self.max_lifetime_seconds:
            raise InvalidToken
        if expires <= issued:
            raise InvalidToken
        return _subject(claims["sub"])


def _subject(value: object) -> str:
    # Same shape as users.authentication_subject (nonblank text); kept verbatim.
    if (
        not isinstance(value, str)
        or not 0 < len(value) <= MAX_SUBJECT_CHARS
        or value != value.strip()
        or any(unicodedata.category(c) in ("Cc", "Cf", "Zl", "Zp") for c in value)
    ):
        raise InvalidToken
    return value
