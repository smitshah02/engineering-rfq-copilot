# Development Log: Day 21 — Role-Based Access Control and Authorization

Date: 2026-11-10

## Objective

Enforce database-backed permissions on every protected route, as a third check alongside authentication and customer binding. Technical description: [day_21_rbac_authorization.md](../development/day_21_rbac_authorization.md).

Baseline: Day 20 complete and uncommitted on top of `df2b9e0`; 1588 tests passing.

## Design

- **Permission source:** `business.role_permissions` grants (`allowed = true`) for `users.role`, resolved by `get_principal` in its existing read-only session, after the binding. No cache.
- **Principal:** gains `permissions: frozenset[str]`, empty by default (deny). It holds no role.
- **Enforcement:** `require_permission(name)` dependency as the first parameter of each protected handler: 403 before any session, storage or body work.
- **Mapping:** `view_customer` for the profile, `view_assigned_rfqs` for the RFQ, attachment-list, catalog and released-quote reads, and `create_rfq` for upload. The gaps are documented as TD-014 to TD-017; no permission was invented.
- **Approval:** no route requires or performs an approval action.

## Files

| File | Change |
| --- | --- |
| `src/rfq_copilot/api/auth.py` | `Principal.permissions`; grants resolved in `get_principal`; permission constants; `require_permission`. |
| `src/rfq_copilot/repositories/identity.py`, `repositories/__init__.py` | New `granted_permissions`. |
| `src/rfq_copilot/api/routers/{customers,rfqs,materials,quotes,attachments}.py` | The handler's principal dependency is now `require_permission(...)`. |
| `tests/test_rbac.py` | New. 30 public tests. |
| `tests/test_day21_rbac_database.py` | New. 13 PostgreSQL tests, real tokens. |
| `tests/test_auth.py` | The fake identity store also fakes grants. |
| `tests/test_api_reads.py`, `test_attachments.py`, `test_day18_api_database.py`, `test_day19_attachments_database.py` | Each injected `Principal` now carries exactly the permissions its routes need (`READS` or `UPLOADS`; plus `view_customer` in one test that reads the profile). No assertion was removed. |
| `.github/workflows/smoke.yml`, `README.md` | Smoke suite adds `tests/test_rbac.py`; features, status and 403 answers. |
| `docs/development/technical_debt.md` | TD-014 to TD-017 added. TD-009, TD-010, TD-011, TD-013 and the Day 19 limitations restated as open. |
| `docs/development/day_21_rbac_authorization.md` | New. |

Not changed: ORM models, migrations, `api/tokens.py`, bindings, business services and engines, rule versions, evaluation fingerprints, dataset, development data.

## Problems found and fixed

1. As intended, the 5 existing dependency-override sites began answering 403, because an injected principal now carries no permissions. Each was given the exact grants its routes need.
2. A Day 19 database test read `/customers/me` with upload-only grants. It was given `view_customer` as well.
3. A first route-coverage test walked `app.routes`. FastAPI 0.162 wraps included routers in a private `_IncludedRouter`, so it saw no routes. It was replaced by enumerating the public OpenAPI schema, plus behavioural checks per route.
4. The seed has no `released` quote. The per-role and approval tests release one approved quote inside the fixture transaction (rolled back), as the Day 18 tests do.
5. A statement-count assertion counted the fixture's SAVEPOINT statements and a query from the test itself. That query was moved out of the capture, and savepoints were filtered.
6. A grant-combination helper fell back to `pytest.skip`. It was changed to `pytest.fail`, so a missing role can never pass silently.

## Verification (commands and actual results)

| Command | Result |
| --- | --- |
| `.venv/bin/python -m pytest -q tests/test_rbac.py tests/test_day21_rbac_database.py` | 43 passed in 6.52s |
| Days 16–20 API tests (`test_api`, `_schemas`, `_reads`, `day18`, `attachments`, `day19`, `auth`, `day20`) | 469 passed in 16.73s |
| Public smoke (8 files, `env -u DATABASE_URL`) | 501 passed in 1.91s |
| `.venv/bin/python -m pytest -q` | 1631 passed in 152.85s; 0 failed, 0 skipped, 0 warnings |
| Mutations: bypass / token claims / no scoping / ignore `allowed` / any role / approval-implies-access / upload unprotected | 35 / 23 / 1 / 2 / 9 / 12 / 20 failed (of 43) |
| `.venv/bin/ruff check .` | All checks passed |
| `.venv/bin/ruff format --check src tests alembic` | 112 files already formatted |
| `uv lock --check` | Resolved 46 packages, pass |
| `python -m rfq_copilot.integrity --target development …` | PASS, records 1090, violations 0 |
| Uvicorn, production, ES256, development DB read only | live and info 200; no token, bad signature, unknown subject, spoofed headers: 401 ×7; valid unbound user and forged role claims: 403 ×7; no token, subject or error in the log |
| Guarded test database after the Day 21 runs | 0 user relations |

## Git status at end of day

Nothing staged or committed. `day20_review_bundle.zip`, which was untracked at the start of the session, is no longer in the working tree. No command in this session removed it.

```
 M .github/workflows/smoke.yml
 M README.md
 M docs/development/technical_debt.md
 M pyproject.toml
 M src/rfq_copilot/api/app.py
 M src/rfq_copilot/api/auth.py
 M src/rfq_copilot/api/config.py
 M src/rfq_copilot/api/routers/attachments.py
 M src/rfq_copilot/api/routers/customers.py
 M src/rfq_copilot/api/routers/materials.py
 M src/rfq_copilot/api/routers/quotes.py
 M src/rfq_copilot/api/routers/rfqs.py
 M src/rfq_copilot/integrity.py
 M src/rfq_copilot/models/__init__.py
 M src/rfq_copilot/models/identity.py
 M src/rfq_copilot/repositories/__init__.py
 M src/rfq_copilot/seeding/mapping.py
 M src/rfq_copilot/seeding/safety.py
 M tests/test_api_reads.py
 M tests/test_attachments.py
 M tests/test_database_end_to_end.py
 M tests/test_database_integrity.py
 M tests/test_database_migrations.py
 M tests/test_database_seeding.py
 M tests/test_day18_api_database.py
 M tests/test_day19_attachments_database.py
 M tests/test_orm_models.py
 M uv.lock
?? alembic/versions/20261110_01_user_customer_bindings.py
?? docs/dev_log/day_20.md
?? docs/dev_log/day_21.md
?? docs/development/day_20_authentication.md
?? docs/development/day_21_rbac_authorization.md
?? src/rfq_copilot/api/tokens.py
?? src/rfq_copilot/repositories/identity.py
?? tests/test_auth.py
?? tests/test_day20_auth_database.py
?? tests/test_day21_rbac_database.py
?? tests/test_rbac.py
```
